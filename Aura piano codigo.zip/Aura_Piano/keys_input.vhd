LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY keys_input IS
    GENERIC (
        STABLE_CYCLES : POSITIVE := 500000
    );
    PORT (
        clk, rst : IN STD_LOGIC;
        keys_async : IN STD_LOGIC_VECTOR(6 DOWNTO 0);
        key_state, key_pulse : OUT STD_LOGIC_VECTOR(6 DOWNTO 0)
    );
END ENTITY;
ARCHITECTURE rtl OF keys_input IS
    SIGNAL keys_synced, keys_clean : STD_LOGIC_VECTOR(6 DOWNTO 0);
BEGIN
    entradas : FOR i IN 0 TO 6 GENERATE
        sincronizador : ENTITY WORK.input_sync
            PORT MAP (
                clk => clk, rst => rst, input_async => keys_async(i),
                input_synced => keys_synced(i)
            );
        antirrebote : ENTITY WORK.debounce
            GENERIC MAP (STABLE_CYCLES => STABLE_CYCLES)
            PORT MAP (
                clk => clk, rst => rst, input_synced => keys_synced(i),
                input_clean => keys_clean(i)
            );
    END GENERATE;
    detector : ENTITY WORK.key_detector
        PORT MAP (
            clk => clk, rst => rst, keys => keys_clean,
            key_state => key_state, key_pulse => key_pulse
        );
END ARCHITECTURE;
