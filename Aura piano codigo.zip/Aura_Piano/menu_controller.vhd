LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY menu_controller IS
    PORT (clk, rst, up_press, down_press : IN STD_LOGIC;
          screen : IN INTEGER RANGE 0 TO 6;
          song_mode, song_sel : OUT STD_LOGIC);
END ENTITY;
ARCHITECTURE rtl OF menu_controller IS
    SIGNAL mode_s, song_s : STD_LOGIC;
BEGIN
    PROCESS(clk, rst)
    BEGIN
        IF rst = '1' THEN
            mode_s <= '0';
            song_s <= '0';
        ELSIF rising_edge(clk) THEN
            IF up_press /= down_press THEN
                CASE screen IS
                    WHEN 1 => mode_s <= NOT mode_s;
                    WHEN 3 => song_s <= NOT song_s;
                    WHEN OTHERS => NULL;
                END CASE;
            END IF;
        END IF;
    END PROCESS;
    song_mode <= mode_s;
    song_sel <= song_s;
END ARCHITECTURE;
