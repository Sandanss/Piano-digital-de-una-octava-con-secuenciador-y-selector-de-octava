LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY note_comparator IS
    PORT (key_pulse : IN STD_LOGIC_VECTOR(6 DOWNTO 0);
          expected : IN INTEGER RANGE 0 TO 6;
          correct : OUT STD_LOGIC;
          mistakes : OUT INTEGER RANGE 0 TO 6);
END ENTITY;
ARCHITECTURE rtl OF note_comparator IS
BEGIN
    PROCESS(key_pulse, expected)
        VARIABLE count : INTEGER RANGE 0 TO 6;
    BEGIN
        count := 0;
        FOR i IN 0 TO 6 LOOP
            IF i /= expected AND key_pulse(i) = '1' THEN
                count := count + 1;
            END IF;
        END LOOP;
        mistakes <= count;
    END PROCESS;
    correct <= key_pulse(expected);
END ARCHITECTURE;
