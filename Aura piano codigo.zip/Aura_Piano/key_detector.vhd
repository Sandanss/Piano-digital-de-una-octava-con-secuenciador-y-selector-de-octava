LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY key_detector IS
    PORT (
        clk, rst : IN STD_LOGIC;
        keys : IN STD_LOGIC_VECTOR(6 DOWNTO 0);
        key_state : OUT STD_LOGIC_VECTOR(6 DOWNTO 0);
        key_pulse : OUT STD_LOGIC_VECTOR(6 DOWNTO 0)
    );
END ENTITY;
ARCHITECTURE rtl OF key_detector IS
    SIGNAL keys_s : STD_LOGIC_VECTOR(6 DOWNTO 0);
BEGIN
    PROCESS(clk, rst)
    BEGIN
        IF rst = '1' THEN
            keys_s <= (OTHERS => '0');
            key_pulse <= (OTHERS => '0');
        ELSIF rising_edge(clk) THEN
            key_pulse <= keys AND (NOT keys_s);
            keys_s <= keys;
        END IF;
    END PROCESS;
    key_state <= keys_s;
END ARCHITECTURE;
