LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY piano_renderer IS
    PORT (x : IN INTEGER RANGE 0 TO 799; y : IN INTEGER RANGE 0 TO 524;
          key_state : IN STD_LOGIC_VECTOR(6 DOWNTO 0);
          expected : IN INTEGER RANGE 0 TO 6;
          guide : IN STD_LOGIC;
          draw_key : OUT STD_LOGIC;
          color : OUT STD_LOGIC_VECTOR(11 DOWNTO 0));
END ENTITY;
ARCHITECTURE rtl OF piano_renderer IS
BEGIN
    PROCESS(x, y, key_state, expected, guide)
    BEGIN
        draw_key <= '0';
        color <= x"000";
        FOR i IN 0 TO 6 LOOP
            IF x >= 48 + 78 * i AND x < 120 + 78 * i AND y >= 256 AND y < 416 THEN
                draw_key <= '1';
                IF key_state(i) = '1' THEN
                    color <= x"5DF";
                ELSIF guide = '1' AND expected = i THEN
                    color <= x"FD6";
                ELSE
                    color <= x"EEF";
                END IF;
            END IF;
        END LOOP;
    END PROCESS;
END ARCHITECTURE;
