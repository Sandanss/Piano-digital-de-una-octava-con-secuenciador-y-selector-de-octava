LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY audio_mixer IS
    PORT (
        key_state, note_waves : IN STD_LOGIC_VECTOR(6 DOWNTO 0);
        audio_sample : OUT INTEGER RANGE 0 TO 255
    );
END ENTITY;
ARCHITECTURE rtl OF audio_mixer IS
BEGIN
    PROCESS(key_state, note_waves)
        VARIABLE sample_sum : INTEGER RANGE 2 TO 254;
    BEGIN
        sample_sum := 128;
        FOR i IN 0 TO 6 LOOP
            IF key_state(i) = '1' THEN
                IF note_waves(i) = '1' THEN
                    sample_sum := sample_sum + 18;
                ELSE
                    sample_sum := sample_sum - 18;
                END IF;
            END IF;
        END LOOP;
        audio_sample <= sample_sum;
    END PROCESS;
END ARCHITECTURE;
