LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY digital_oscillator IS
    PORT (
        clk, rst, ena : IN STD_LOGIC;
        half_period : IN INTEGER RANGE 0 TO 200000;
        note_wave : OUT STD_LOGIC
    );
END ENTITY;
ARCHITECTURE rtl OF digital_oscillator IS
    SIGNAL count_s : INTEGER RANGE 0 TO 199999;
    SIGNAL wave_s : STD_LOGIC;
BEGIN
    PROCESS(clk, rst)
    BEGIN
        IF rst = '1' THEN
            count_s <= 0;
            wave_s <= '0';
        ELSIF rising_edge(clk) THEN
            IF ena = '0' OR half_period = 0 THEN
                count_s <= 0;
                wave_s <= '0';
            ELSIF count_s >= half_period - 1 THEN
                count_s <= 0;
                wave_s <= NOT wave_s;
            ELSE
                count_s <= count_s + 1;
            END IF;
        END IF;
    END PROCESS;
    note_wave <= wave_s;
END ARCHITECTURE;
