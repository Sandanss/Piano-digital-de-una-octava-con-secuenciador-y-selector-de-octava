LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY song_rom IS
    PORT (song_sel : IN STD_LOGIC;
          position : IN INTEGER RANGE 0 TO 7;
          note_index : OUT INTEGER RANGE 0 TO 6);
END ENTITY;
ARCHITECTURE rtl OF song_rom IS
    TYPE melody IS ARRAY (0 TO 7) OF INTEGER RANGE 0 TO 6;
    CONSTANT escala : melody := (0, 1, 2, 3, 4, 5, 6, 0);
    CONSTANT arpegio : melody := (0, 2, 4, 2, 0, 2, 4, 0);
BEGIN
    note_index <= escala(position) WHEN song_sel = '0' ELSE arpegio(position);
END ARCHITECTURE;
