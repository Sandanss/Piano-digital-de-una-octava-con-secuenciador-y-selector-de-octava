LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY octave_selector IS
    PORT (
        low_switch, high_switch : IN STD_LOGIC;
        octave_sel : OUT STD_LOGIC_VECTOR(1 DOWNTO 0)
    );
END ENTITY;
ARCHITECTURE rtl OF octave_selector IS
BEGIN
    octave_sel <= "00" WHEN low_switch = '1' AND high_switch = '0' ELSE
                  "10" WHEN low_switch = '0' AND high_switch = '1' ELSE
                  "01";
END ARCHITECTURE;
