LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY song_controller IS
    PORT (clk, rst, clear_song, playing, correct : IN STD_LOGIC;
          position : OUT INTEGER RANGE 0 TO 7;
          finished : OUT STD_LOGIC);
END ENTITY;
ARCHITECTURE rtl OF song_controller IS
    SIGNAL position_s : INTEGER RANGE 0 TO 7;
    SIGNAL finished_s : STD_LOGIC;
BEGIN
    PROCESS(clk, rst)
    BEGIN
        IF rst = '1' THEN
            position_s <= 0;
            finished_s <= '0';
        ELSIF rising_edge(clk) THEN
            IF clear_song = '1' THEN
                position_s <= 0;
                finished_s <= '0';
            ELSIF playing = '1' AND correct = '1' AND finished_s = '0' THEN
                IF position_s = 7 THEN finished_s <= '1';
                ELSE position_s <= position_s + 1;
                END IF;
            END IF;
        END IF;
    END PROCESS;
    position <= position_s;
    finished <= finished_s;
END ARCHITECTURE;
