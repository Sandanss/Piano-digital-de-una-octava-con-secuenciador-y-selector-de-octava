LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY debounce IS
    GENERIC (
        STABLE_CYCLES : POSITIVE := 500000
    );
    PORT (
        clk, rst : IN STD_LOGIC;
        input_synced : IN STD_LOGIC;
        input_clean : OUT STD_LOGIC
    );
END ENTITY;
ARCHITECTURE rtl OF debounce IS
    SIGNAL count_s : INTEGER RANGE 0 TO STABLE_CYCLES - 1;
    SIGNAL clean_s : STD_LOGIC;
BEGIN
    PROCESS(clk, rst)
    BEGIN
        IF rst = '1' THEN
            count_s <= 0;
            clean_s <= '0';
        ELSIF rising_edge(clk) THEN
            IF input_synced = clean_s THEN
                count_s <= 0;
            ELSIF count_s = STABLE_CYCLES - 1 THEN
                clean_s <= input_synced;
                count_s <= 0;
            ELSE
                count_s <= count_s + 1;
            END IF;
        END IF;
    END PROCESS;
    input_clean <= clean_s;
END ARCHITECTURE;
