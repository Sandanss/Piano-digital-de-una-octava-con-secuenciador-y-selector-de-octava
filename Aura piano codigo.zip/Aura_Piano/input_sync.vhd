LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY input_sync IS
    PORT (
        clk, rst : IN STD_LOGIC;
        input_async : IN STD_LOGIC;
        input_synced : OUT STD_LOGIC
    );
END ENTITY;
ARCHITECTURE rtl OF input_sync IS
    SIGNAL input_meta, input_s : STD_LOGIC;
BEGIN
    PROCESS(clk, rst)
    BEGIN
        IF rst = '1' THEN
            input_meta <= '0';
            input_s <= '0';
        ELSIF rising_edge(clk) THEN
            input_meta <= input_async;
            input_s <= input_meta;
        END IF;
    END PROCESS;
    input_synced <= input_s;
END ARCHITECTURE;
