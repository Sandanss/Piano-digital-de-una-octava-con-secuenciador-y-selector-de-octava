create_clock -name clk -period 20.000 [get_ports {clk}]
derive_clock_uncertainty
set_false_path -from [get_ports {rst keys_async[*] controls_async[*] octave_switches_async[*]}]
