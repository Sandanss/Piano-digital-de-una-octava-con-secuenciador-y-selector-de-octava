LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY vga_sync IS
    PORT (clk, rst, pixel_tick : IN STD_LOGIC;
          x : OUT INTEGER RANGE 0 TO 799;
          y : OUT INTEGER RANGE 0 TO 524;
          hsync, vsync, visible : OUT STD_LOGIC);
END ENTITY;
ARCHITECTURE rtl OF vga_sync IS
    SIGNAL x_s : INTEGER RANGE 0 TO 799;
    SIGNAL y_s : INTEGER RANGE 0 TO 524;
BEGIN
    PROCESS(clk, rst)
    BEGIN
        IF rst = '1' THEN
            x_s <= 0;
            y_s <= 0;
        ELSIF rising_edge(clk) THEN
            IF pixel_tick = '1' THEN
                IF x_s = 799 THEN
                    x_s <= 0;
                    IF y_s = 524 THEN y_s <= 0;
                    ELSE y_s <= y_s + 1;
                    END IF;
                ELSE x_s <= x_s + 1;
                END IF;
            END IF;
        END IF;
    END PROCESS;
    x <= x_s;
    y <= y_s;
    hsync <= '0' WHEN x_s >= 656 AND x_s < 752 ELSE '1';
    vsync <= '0' WHEN y_s >= 490 AND y_s < 492 ELSE '1';
    visible <= '1' WHEN x_s < 640 AND y_s < 480 ELSE '0';
END ARCHITECTURE;
