LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY note_frequency IS
    PORT (
        note_sel : IN STD_LOGIC_VECTOR(2 DOWNTO 0);
        octave_sel : IN STD_LOGIC_VECTOR(1 DOWNTO 0);
        half_period : OUT INTEGER RANGE 0 TO 200000
    );
END ENTITY;
ARCHITECTURE rtl OF note_frequency IS
    TYPE period_table IS ARRAY (0 TO 7) OF INTEGER RANGE 0 TO 200000;
    CONSTANT low_periods : period_table :=
        (191113, 170262, 151686, 143173, 127553, 113636, 101238, 0);
    CONSTANT mid_periods : period_table :=
        (95556, 85131, 75843, 71586, 63776, 56818, 50619, 0);
    CONSTANT high_periods : period_table :=
        (47778, 42566, 37922, 35793, 31888, 28409, 25310, 0);
    SIGNAL note_index : INTEGER RANGE 0 TO 7;
BEGIN
    WITH note_sel SELECT
        note_index <= 0 WHEN "000",
                      1 WHEN "001",
                      2 WHEN "010",
                      3 WHEN "011",
                      4 WHEN "100",
                      5 WHEN "101",
                      6 WHEN "110",
                      7 WHEN OTHERS;
    WITH octave_sel SELECT
        half_period <= low_periods(note_index) WHEN "00",
                       high_periods(note_index) WHEN "10",
                       mid_periods(note_index) WHEN OTHERS;
END ARCHITECTURE;
