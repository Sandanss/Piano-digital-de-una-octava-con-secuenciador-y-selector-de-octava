LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY aura_piano_top IS
    GENERIC (STABLE_CYCLES : POSITIVE := 500000);
    PORT (clk, rst : IN STD_LOGIC;
          keys_async : IN STD_LOGIC_VECTOR(6 DOWNTO 0);
          octave_switches_async : IN STD_LOGIC_VECTOR(1 DOWNTO 0);
          controls_async : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
          pwm_out, vga_hsync, vga_vsync : OUT STD_LOGIC;
          vga_r, vga_g, vga_b : OUT STD_LOGIC_VECTOR(3 DOWNTO 0));
END ENTITY;
ARCHITECTURE rtl OF aura_piano_top IS
    SIGNAL reset_pipe : STD_LOGIC_VECTOR(1 DOWNTO 0);
    SIGNAL rst_s : STD_LOGIC;
    SIGNAL key_state, key_pulse, audio_keys : STD_LOGIC_VECTOR(6 DOWNTO 0);
    SIGNAL panel_raw, panel_sync, panel_clean : STD_LOGIC_VECTOR(5 DOWNTO 0);
    SIGNAL controls_prev, controls_pulse : STD_LOGIC_VECTOR(3 DOWNTO 0);
    SIGNAL octave_sel : STD_LOGIC_VECTOR(1 DOWNTO 0);
    SIGNAL screen : INTEGER RANGE 0 TO 6;
    SIGNAL song_mode, song_sel, clear_song, playing, show_keys : STD_LOGIC;
    SIGNAL correct, song_done : STD_LOGIC;
    SIGNAL position : INTEGER RANGE 0 TO 7;
    SIGNAL expected, mistakes : INTEGER RANGE 0 TO 6;
    SIGNAL hits : INTEGER RANGE 0 TO 8;
    SIGNAL errors : INTEGER RANGE 0 TO 99;
    SIGNAL x : INTEGER RANGE 0 TO 799;
    SIGNAL y : INTEGER RANGE 0 TO 524;
    SIGNAL pixel_tick, visible, hsync, vsync, ink, draw_key : STD_LOGIC;
    SIGNAL font_row, font_col : INTEGER RANGE 0 TO 7;
    SIGNAL screen_glyph, song_glyph, glyph : CHARACTER;
    SIGNAL key_color, rgb : STD_LOGIC_VECTOR(11 DOWNTO 0);
BEGIN
    PROCESS(clk, rst)
    BEGIN
        IF rst = '1' THEN
            reset_pipe <= "11";
        ELSIF rising_edge(clk) THEN
            reset_pipe <= reset_pipe(0) & '0';
        END IF;
    END PROCESS;
    rst_s <= reset_pipe(1);
    teclas : ENTITY WORK.keys_input
        GENERIC MAP (STABLE_CYCLES => STABLE_CYCLES)
        PORT MAP (clk, rst_s, keys_async, key_state, key_pulse);
    panel_raw <= octave_switches_async & controls_async;
    panel : FOR i IN 0 TO 5 GENERATE
        sincronizador : ENTITY WORK.input_sync
            PORT MAP (clk, rst_s, panel_raw(i), panel_sync(i));
        antirrebote : ENTITY WORK.debounce
            GENERIC MAP (STABLE_CYCLES => STABLE_CYCLES)
            PORT MAP (clk, rst_s, panel_sync(i), panel_clean(i));
    END GENERATE;
    PROCESS(clk, rst_s)
    BEGIN
        IF rst_s = '1' THEN
            controls_prev <= (OTHERS => '0');
            controls_pulse <= (OTHERS => '0');
        ELSIF rising_edge(clk) THEN
            controls_prev <= panel_clean(3 DOWNTO 0);
            controls_pulse <= panel_clean(3 DOWNTO 0) AND NOT controls_prev;
        END IF;
    END PROCESS;
    octavas : ENTITY WORK.octave_selector
        PORT MAP (panel_clean(4), panel_clean(5), octave_sel);
    seleccion : ENTITY WORK.menu_controller
        PORT MAP (clk, rst_s, controls_pulse(0), controls_pulse(1), screen,
                  song_mode, song_sel);
    control : ENTITY WORK.game_fsm
        PORT MAP (clk, rst_s, controls_pulse(2), controls_pulse(3), song_done,
                  song_mode, screen);
    clear_song <= '1' WHEN screen = 3 ELSE '0';
    playing <= '1' WHEN screen = 4 AND song_done = '0' AND controls_pulse(3) = '0' ELSE '0';
    canciones : ENTITY WORK.song_rom PORT MAP (song_sel, position, expected);
    comparador : ENTITY WORK.note_comparator PORT MAP (key_pulse, expected, correct, mistakes);
    cancion : ENTITY WORK.song_controller
        PORT MAP (clk, rst_s, clear_song, playing, correct, position, song_done);
    marcador : ENTITY WORK.score_counter
        PORT MAP (clk, rst_s, clear_song, playing, correct, mistakes, hits, errors);
    show_keys <= '1' WHEN screen = 2 OR screen = 4 ELSE '0';
    audio_keys <= key_state WHEN show_keys = '1' ELSE (OTHERS => '0');
    audio : ENTITY WORK.audio_engine PORT MAP (clk, rst_s, audio_keys, octave_sel, pwm_out);
    ritmo : ENTITY WORK.vga_clock PORT MAP (clk, rst_s, pixel_tick);
    barrido : ENTITY WORK.vga_sync PORT MAP (clk, rst_s, pixel_tick, x, y, hsync, vsync, visible);
    pantalla : ENTITY WORK.screen_renderer PORT MAP (x, y, screen, song_mode, song_sel, screen_glyph);
    texto_cancion : ENTITY WORK.song_renderer PORT MAP (x, y, screen, expected, hits, errors, song_glyph);
    glyph <= screen_glyph WHEN song_glyph = ' ' ELSE song_glyph;
    font_row <= (y / 2) MOD 8;
    font_col <= (x / 2) MOD 8;
    fuente : ENTITY WORK.font_rom PORT MAP (glyph, font_row, font_col, ink);
    piano : ENTITY WORK.piano_renderer PORT MAP (x, y, key_state, expected, playing, draw_key, key_color);
    imagen : ENTITY WORK.vga_compositor PORT MAP (visible, ink, show_keys, draw_key, key_color, rgb);
    PROCESS(clk, rst_s)
    BEGIN
        IF rst_s = '1' THEN
            vga_hsync <= '1';
            vga_vsync <= '1';
            vga_r <= (OTHERS => '0');
            vga_g <= (OTHERS => '0');
            vga_b <= (OTHERS => '0');
        ELSIF rising_edge(clk) THEN
            IF pixel_tick = '1' THEN
                vga_hsync <= hsync;
                vga_vsync <= vsync;
                vga_r <= rgb(11 DOWNTO 8);
                vga_g <= rgb(7 DOWNTO 4);
                vga_b <= rgb(3 DOWNTO 0);
            END IF;
        END IF;
    END PROCESS;
END ARCHITECTURE;
