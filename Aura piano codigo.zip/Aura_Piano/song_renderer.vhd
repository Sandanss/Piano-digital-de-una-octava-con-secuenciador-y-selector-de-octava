LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY song_renderer IS
    PORT (x : IN INTEGER RANGE 0 TO 799; y : IN INTEGER RANGE 0 TO 524;
          screen : IN INTEGER RANGE 0 TO 6;
          expected : IN INTEGER RANGE 0 TO 6;
          hits : IN INTEGER RANGE 0 TO 8;
          errors : IN INTEGER RANGE 0 TO 99;
          glyph : OUT CHARACTER);
END ENTITY;
ARCHITECTURE rtl OF song_renderer IS
    TYPE note_names IS ARRAY (0 TO 6) OF STRING(1 TO 3);
    CONSTANT names : note_names := ("DO ", "RE ", "MI ", "FA ", "SOL", "LA ", "SI ");
    CONSTANT digits : STRING(1 TO 10) := "0123456789";
BEGIN
    PROCESS(x, y, screen, expected, hits, errors)
        VARIABLE line_text : STRING(1 TO 28);
    BEGIN
        line_text := (OTHERS => ' ');
        IF screen = 4 AND y / 16 = 5 THEN
            line_text := "TOCA                        ";
            line_text(6 TO 8) := names(expected);
        ELSIF (screen = 4 OR screen = 6) AND y / 16 = 7 THEN
            line_text := "ACIERTOS 0/8   ERRORES 00   ";
            line_text(10) := digits(hits + 1);
            line_text(24) := digits(errors / 10 + 1);
            line_text(25) := digits(errors MOD 10 + 1);
        END IF;
        glyph <= ' ';
        IF x >= 48 AND x < 496 THEN
            glyph <= line_text((x - 48) / 16 + 1);
        END IF;
    END PROCESS;
END ARCHITECTURE;
