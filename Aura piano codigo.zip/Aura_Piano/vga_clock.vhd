LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY vga_clock IS
    PORT (clk, rst : IN STD_LOGIC; pixel_tick : OUT STD_LOGIC);
END ENTITY;
ARCHITECTURE rtl OF vga_clock IS
    SIGNAL tick_s : STD_LOGIC;
BEGIN
    PROCESS(clk, rst)
    BEGIN
        IF rst = '1' THEN tick_s <= '0';
        ELSIF rising_edge(clk) THEN tick_s <= NOT tick_s;
        END IF;
    END PROCESS;
    pixel_tick <= tick_s;
END ARCHITECTURE;
