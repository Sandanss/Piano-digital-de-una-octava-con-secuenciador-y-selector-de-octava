LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY pwm_generator IS
    PORT (
        clk, rst : IN STD_LOGIC;
        audio_sample : IN INTEGER RANGE 0 TO 255;
        pwm_out : OUT STD_LOGIC
    );
END ENTITY;
ARCHITECTURE rtl OF pwm_generator IS
    SIGNAL carrier_s : INTEGER RANGE 0 TO 255;
    SIGNAL sample_s : INTEGER RANGE 0 TO 255;
BEGIN
    PROCESS(clk, rst)
    BEGIN
        IF rst = '1' THEN
            carrier_s <= 0;
            sample_s <= 0;
        ELSIF rising_edge(clk) THEN
            IF carrier_s = 255 THEN
                carrier_s <= 0;
                sample_s <= audio_sample;
            ELSE
                carrier_s <= carrier_s + 1;
            END IF;
        END IF;
    END PROCESS;
    pwm_out <= '1' WHEN carrier_s < sample_s ELSE '0';
END ARCHITECTURE;
