LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY screen_renderer IS
    PORT (x : IN INTEGER RANGE 0 TO 799; y : IN INTEGER RANGE 0 TO 524;
          screen : IN INTEGER RANGE 0 TO 6;
          song_mode, song_sel : IN STD_LOGIC;
          glyph : OUT CHARACTER);
END ENTITY;
ARCHITECTURE rtl OF screen_renderer IS
BEGIN
    PROCESS(x, y, screen, song_mode, song_sel)
        VARIABLE line_text : STRING(1 TO 28);
    BEGIN
        line_text := (OTHERS => ' ');
        CASE y / 16 IS
            WHEN 2 =>
                CASE screen IS
                    WHEN 0 => line_text := "AURA PIANO                  ";
                    WHEN 1 => line_text := "MENU PRINCIPAL              ";
                    WHEN 2 => line_text := "PIANO LIBRE                 ";
                    WHEN 3 => line_text := "ELIGE UNA CANCION           ";
                    WHEN 4 => line_text := "SIGUE LA CANCION            ";
                    WHEN 5 => line_text := "PAUSA                       ";
                    WHEN 6 => line_text := "RESULTADOS                  ";
                END CASE;
            WHEN 5 =>
                CASE screen IS
                    WHEN 0 => line_text := "PRESIONA ENTER              ";
                    WHEN 1 =>
                        IF song_mode = '0' THEN line_text := "> PIANO LIBRE               ";
                        ELSE line_text := "  PIANO LIBRE               ";
                        END IF;
                    WHEN 3 =>
                        IF song_sel = '0' THEN line_text := "> ESCALA                    ";
                        ELSE line_text := "  ESCALA                    ";
                        END IF;
                    WHEN 5 => line_text := "ENTER PARA VOLVER           ";
                    WHEN OTHERS => NULL;
                END CASE;
            WHEN 7 =>
                CASE screen IS
                    WHEN 1 =>
                        IF song_mode = '1' THEN line_text := "> CANCIONES                 ";
                        ELSE line_text := "  CANCIONES                 ";
                        END IF;
                    WHEN 3 =>
                        IF song_sel = '1' THEN line_text := "> ARPEGIO                   ";
                        ELSE line_text := "  ARPEGIO                   ";
                        END IF;
                    WHEN 5 => line_text := "ESC PARA IR AL MENU         ";
                    WHEN OTHERS => NULL;
                END CASE;
            WHEN 10 =>
                CASE screen IS
                    WHEN 1 | 3 => line_text := "SUBE / BAJA Y PULSA ENTER   ";
                    WHEN 2 | 4 => line_text := "ESC PARA PAUSAR             ";
                    WHEN 6 => line_text := "ENTER PARA ELEGIR CANCION   ";
                    WHEN OTHERS => NULL;
                END CASE;
            WHEN OTHERS => NULL;
        END CASE;
        glyph <= ' ';
        IF x >= 48 AND x < 496 THEN
            glyph <= line_text((x - 48) / 16 + 1);
        END IF;
    END PROCESS;
END ARCHITECTURE;
