LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY game_fsm IS
    PORT (clk, rst, confirm, back, song_done : IN STD_LOGIC;
          song_mode : IN STD_LOGIC;
          screen : OUT INTEGER RANGE 0 TO 6);
END ENTITY;
ARCHITECTURE rtl OF game_fsm IS
    TYPE state_type IS (inicio, menu, libre, canciones, juego, pausa, resultados);
    SIGNAL state_s, resume_s : state_type;
BEGIN
    PROCESS(clk, rst)
    BEGIN
        IF rst = '1' THEN
            state_s <= inicio;
            resume_s <= libre;
        ELSIF rising_edge(clk) THEN
            CASE state_s IS
                WHEN inicio =>
                    IF confirm = '1' THEN state_s <= menu; END IF;
                WHEN menu =>
                    IF back = '1' THEN state_s <= inicio;
                    ELSIF confirm = '1' THEN
                        IF song_mode = '1' THEN state_s <= canciones;
                        ELSE state_s <= libre;
                        END IF;
                    END IF;
                WHEN canciones =>
                    IF back = '1' THEN state_s <= menu;
                    ELSIF confirm = '1' THEN state_s <= juego;
                    END IF;
                WHEN libre | juego =>
                    IF state_s = juego AND song_done = '1' THEN state_s <= resultados;
                    ELSIF back = '1' THEN
                        resume_s <= state_s;
                        state_s <= pausa;
                    END IF;
                WHEN pausa =>
                    IF back = '1' THEN state_s <= menu;
                    ELSIF confirm = '1' THEN state_s <= resume_s;
                    END IF;
                WHEN resultados =>
                    IF confirm = '1' OR back = '1' THEN state_s <= canciones; END IF;
            END CASE;
        END IF;
    END PROCESS;
    screen <= state_type'POS(state_s);
END ARCHITECTURE;
