LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY vga_compositor IS
    PORT (visible, text_ink, show_keys, draw_key : IN STD_LOGIC;
          key_color : IN STD_LOGIC_VECTOR(11 DOWNTO 0);
          rgb : OUT STD_LOGIC_VECTOR(11 DOWNTO 0));
END ENTITY;
ARCHITECTURE rtl OF vga_compositor IS
BEGIN
    rgb <= x"000" WHEN visible = '0' ELSE
           x"FFF" WHEN text_ink = '1' ELSE
           key_color WHEN show_keys = '1' AND draw_key = '1' ELSE
           x"123";
END ARCHITECTURE;
