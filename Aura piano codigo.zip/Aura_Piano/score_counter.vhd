LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY score_counter IS
    PORT (clk, rst, clear_song, playing, correct : IN STD_LOGIC;
          mistakes : IN INTEGER RANGE 0 TO 6;
          hits : OUT INTEGER RANGE 0 TO 8;
          errors : OUT INTEGER RANGE 0 TO 99);
END ENTITY;
ARCHITECTURE rtl OF score_counter IS
    SIGNAL hits_s : INTEGER RANGE 0 TO 8;
    SIGNAL errors_s : INTEGER RANGE 0 TO 99;
BEGIN
    PROCESS(clk, rst)
    BEGIN
        IF rst = '1' THEN
            hits_s <= 0;
            errors_s <= 0;
        ELSIF rising_edge(clk) THEN
            IF clear_song = '1' THEN
                hits_s <= 0;
                errors_s <= 0;
            ELSIF playing = '1' THEN
                IF correct = '1' AND hits_s < 8 THEN hits_s <= hits_s + 1; END IF;
                IF errors_s + mistakes > 99 THEN errors_s <= 99;
                ELSE errors_s <= errors_s + mistakes;
                END IF;
            END IF;
        END IF;
    END PROCESS;
    hits <= hits_s;
    errors <= errors_s;
END ARCHITECTURE;
