LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
ENTITY audio_engine IS
    PORT (
        clk, rst : IN STD_LOGIC;
        key_state : IN STD_LOGIC_VECTOR(6 DOWNTO 0);
        octave_sel : IN STD_LOGIC_VECTOR(1 DOWNTO 0);
        pwm_out : OUT STD_LOGIC
    );
END ENTITY;
ARCHITECTURE rtl OF audio_engine IS
    TYPE note_codes IS ARRAY (0 TO 6) OF STD_LOGIC_VECTOR(2 DOWNTO 0);
    CONSTANT notes : note_codes :=
        ("000", "001", "010", "011", "100", "101", "110");
    TYPE period_array IS ARRAY (0 TO 6) OF INTEGER RANGE 0 TO 200000;
    SIGNAL half_periods : period_array;
    SIGNAL note_waves : STD_LOGIC_VECTOR(6 DOWNTO 0);
    SIGNAL mixed_sample : INTEGER RANGE 0 TO 255;
BEGIN
    voces : FOR i IN 0 TO 6 GENERATE
        frecuencia : ENTITY WORK.note_frequency
            PORT MAP (
                note_sel => notes(i), octave_sel => octave_sel,
                half_period => half_periods(i)
            );
        oscilador : ENTITY WORK.digital_oscillator
            PORT MAP (
                clk => clk, rst => rst, ena => key_state(i),
                half_period => half_periods(i), note_wave => note_waves(i)
            );
    END GENERATE;
    mezclador : ENTITY WORK.audio_mixer
        PORT MAP (
            key_state => key_state, note_waves => note_waves,
            audio_sample => mixed_sample
        );
    salida_pwm : ENTITY WORK.pwm_generator
        PORT MAP (
            clk => clk, rst => rst, audio_sample => mixed_sample,
            pwm_out => pwm_out
        );
END ARCHITECTURE;
